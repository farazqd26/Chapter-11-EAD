package com.example.chapter11;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnGo;
    EditText txtMsg;
    String msg;
    Button b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtMsg = findViewById(R.id.txtMsg);
        btnGo = findViewById(R.id.btnGo);
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog dialBox = createDialogBox();
                dialBox.show();
                txtMsg.setText("I am here! ");
            }
        });
        b2 = findViewById(R.id.b2);
        b2.setOnClickListener(new View.OnClickListener() {
            String msg2 = "Hello! how are you doing today?";
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(),msg2,Toast.LENGTH_LONG).show();
            }
        });
        Button btnToast = findViewById(R.id.btnToast);
        btnToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),customtoast.class));
            }
        });

    }

    private AlertDialog createDialogBox() {
        AlertDialog myQuittingDialogBox =
                new AlertDialog.Builder(this)
//set message, title, and icon
                        .setTitle("Terminator")
                        .setMessage("Are you sure that you want to quit?")
                        //.setIcon(R.drawable.ic_menu_end_conversation)
//set three option buttons
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                msg = "YES " + Integer.toString(whichButton);
                                txtMsg.setText(msg);
                            }
                        })//setPositiveButton
                        .setNeutralButton("Cancel",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
//whatever should be done when answering "CANCEL" goes here
                                msg = "CANCEL " + Integer.toString(whichButton);
                                txtMsg.setText(msg);
                            }//OnClick
                        })//setNeutralButton
                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
//whatever should be done when answering "NO" goes here
                                msg = "NO " + Integer.toString(whichButton);
                                txtMsg.setText(msg);
                            }
                        })//setNegativeButton

                .create();
                return myQuittingDialogBox;
    }
}